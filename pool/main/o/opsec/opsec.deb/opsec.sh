#!/bin/bash

NETWORK_KILLED=0
NET_IFACES=()

banner() {
cat << "EOF"
 ██████╗ ██████╗ ███████╗███████╗ ██████╗
██╔═══██╗██╔══██╗██╔════╝██╔════╝██╔════╝
██║   ██║██████╔╝███████╗█████╗  ██║
██║   ██║██╔═══╝ ╚════██║██╔══╝  ██║
╚██████╔╝██║     ███████║███████╗╚██████╗
 ╚═════╝ ╚═╝     ╚══════╝╚══════╝ ╚═════╝

        OPSEC MULTITOOL v1.0
EOF
}

pause() {
    read -rp "Press Enter to continue..."
}

i_use_arch_btw() {
    clear

    if command -v fastfetch >/dev/null 2>&1; then
        fastfetch --logo arch 2>/dev/null || fastfetch -l arch
    elif command -v neofetch >/dev/null 2>&1; then
        neofetch --ascii_distro Arch
    else
        echo "Install fastfetch or neofetch first."
    fi
}

disable_network() {
    if [ "$NETWORK_KILLED" -eq 1 ]; then
        echo
        echo "[+] DDoS already active."
        return
    fi

    mapfile -t NET_IFACES < <(
        ip -o link show |
        awk -F': ' '{print $2}' |
        grep -v '^lo$'
    )

    for iface in "${NET_IFACES[@]}"; do
        sudo ip link set "$iface" down 2>/dev/null
    done

    NETWORK_KILLED=1

    echo
    echo "[+] Entire internet has been defeated."
    echo "[+] Network will be restored when OPSEC exits."
}

restore_network() {
    if [ "$NETWORK_KILLED" -eq 0 ]; then
        return
    fi

    for iface in "${NET_IFACES[@]}"; do
        sudo ip link set "$iface" up 2>/dev/null
    done
}

shutdown_animation() {
    [ -f logo.txt ] || return

    mapfile -t lines < logo.txt

    while [ ${#lines[@]} -gt 0 ]; do
        clear

        for line in "${lines[@]}"; do
            echo "$line"
        done

        sleep 0.03

        if [ ${#lines[@]} -gt 2 ]; then
            lines=("${lines[@]:1:${#lines[@]}-2}")
        else
            break
        fi
    done

    clear

    for i in {40..1}; do
        clear
        printf "%*s⣿\n" "$i" ""
        sleep 0.02
    done

    clear
}

trap restore_network EXIT INT TERM

while true; do
    clear
    banner

    echo
    echo "[1] I use Arch BTW"
    echo "[2] DDoS Attack"
    echo "[3] Exit"
    echo

    read -rp "Select option: " choice

    case $choice in
        1)
            i_use_arch_btw
            pause
            ;;

        2)
            clear
            disable_network
            pause
            ;;

        3)
            shutdown_animation
            exit 0
            ;;

        *)
            sleep 1
            ;;
    esac
done
